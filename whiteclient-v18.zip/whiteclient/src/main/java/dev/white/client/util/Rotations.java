package dev.white.client.util;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * The one place that holds the SILENT (server-side) rotation. Any module that wants to turn what the server sees
 * without moving your own view claims it, sets the angles every tick and releases it when done:
 *
 *   Rotations.set(this, yaw, pitch);   // false if another module owns it right now
 *   Rotations.release(this);
 *
 * While a rotation is active:
 *  - the movement packet carries it (ClientPlayerEntityMixin swaps it in while the packet is built),
 *  - your look vector (crosshair picking, ray casts) follows it (EntityMixin#getRotationVec).
 * Your camera is never touched.
 */
public final class Rotations {
    private static Object owner;
    private static boolean active;
    private static float yaw, pitch;

    private Rotations() {}

    public static boolean active() { return active; }
    public static float yaw() { return yaw; }
    public static float pitch() { return pitch; }
    public static boolean ownedBy(Object o) { return owner == o; }
    public static boolean free() { return owner == null; }

    /** Takes (or keeps) ownership and sets the silent angles. False when somebody else owns the rotation. */
    public static boolean set(Object who, float newYaw, float newPitch) {
        if (owner != null && owner != who) return false;
        owner = who;
        active = true;
        yaw = newYaw;
        pitch = MathHelper.clamp(newPitch, -90f, 90f);
        return true;
    }

    /** Gives the rotation back (only if "who" owns it). The server sees your real view again. */
    public static void release(Object who) {
        if (owner != who) return;
        owner = null;
        active = false;
    }

    public static Vec3d viewVector() { return Vec3d.fromPolar(pitch, yaw); }
}
