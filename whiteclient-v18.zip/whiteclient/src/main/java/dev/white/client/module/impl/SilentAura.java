package dev.white.client.module.impl;

import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.Friends;
import dev.white.client.util.Rotations;
import dev.white.client.util.SmoothLook;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Kill aura with SILENT rotations: your own view never moves. It claims the shared silent rotation (util/Rotations),
 * which the movement packet carries (ClientPlayerEntityMixin) and your look vector follows (EntityMixin).
 *
 * Rotation modes:
 *  - IDLE          no target (or nothing to do): the server sees your real view.
 *  - ATTACKING     turning toward the target's aim point; attacks once the weapon is charged AND the server-side
 *                  rotation actually points at the target's hitbox.
 *  - FLICKING_AWAY after a hit (and while the weapon recharges) the server rotation turns back toward your real
 *                  view for a few ticks before it locks on again.
 *
 * Humanising: turn speed is Aim speed times a log-normal random factor (re-rolled every tick, 1.4x..3.0x) and it
 * slows down when the target is very close; the aim point drifts with three smoothed random offsets (AimJitter).
 */
public class SilentAura extends Module {
    public enum Mode { IDLE, FLICKING_AWAY, ATTACKING }

    private final Setting.Num range = add(new Setting.Num("Range", 3.2, 1.0, 6.0, 0.1));
    private final Setting.Num rotateRange = add(new Setting.Num("Rotate range", 4.5, 1.0, 8.0, 0.1));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Other mobs", false));
    private final Setting.Num minCharge = add(new Setting.Num("Min charge", 0.95, 0.1, 1.0, 0.05));
    private final Setting.Num aimSpeed = add(new Setting.Num("Aim speed", 18, 3, 60, 1));        // deg per tick, before the random factor
    private final Setting.Bool jitter = add(new Setting.Bool("Aim jitter", true));
    private final Setting.Bool lookAt = add(new Setting.Bool("Look at target", true));      // your real view follows the target
    private final Setting.Num lookSpeed = add(new Setting.Num("  Look speed (deg/tick)", 20, 2, 60, 1));
    private final Setting.Bool flick = add(new Setting.Bool("Flick away after hit", true));

    private Mode mode = Mode.IDLE;
    private boolean spoof;
    private float yaw, pitch;               // what the server is told
    private LivingEntity target;
    private int flickTicks;
    private final Random rng = new Random();
    private final AimJitter jx = new AimJitter(-0.20, 0.20);
    private final AimJitter jz = new AimJitter(-0.20, 0.20);
    private final AimJitter jy = new AimJitter(-0.20, 0.12);

    public SilentAura() { super("Silent Aura", Category.COMBAT); }

    @Override protected void onEnable() { toIdle(); }
    @Override protected void onDisable() { toIdle(); target = null; }

    private void toIdle() { mode = Mode.IDLE; spoof = false; flickTicks = 0; Rotations.release(this); }

    // ----- tick ----------------------------------------------------------------------------------------------
    /** Start of the tick (before the movement packet is sent): choose target, turn the server-side rotation. */
    @Override
    public void onPreTick() {
        if (mc.player == null || mc.world == null) { toIdle(); target = null; return; }
        if (mc.currentScreen != null || Freecam.active() || mc.player.isUsingItem() || mc.player.isSpectator()) { toIdle(); target = null; return; }

        float realYaw = mc.player.getYaw(), realPitch = mc.player.getPitch();
        if (!spoof) { yaw = realYaw; pitch = realPitch; }

        target = pickTarget();
        if (lookAt.value && target != null) SmoothLook.step(target, lookSpeed.value);   // real view, smooth; the silent angles are separate
        boolean charged = target != null && AutoMaceSwap.progress() >= 0.6f;

        if (mode == Mode.FLICKING_AWAY && flickTicks > 0) flickTicks--;
        if (charged && !(mode == Mode.FLICKING_AWAY && flickTicks > 0)) mode = Mode.ATTACKING;
        else if (!charged && mode == Mode.ATTACKING) { mode = Mode.FLICKING_AWAY; flickTicks = 0; }

        if (mode == Mode.IDLE) return;

        float wantYaw, wantPitch;
        if (mode == Mode.ATTACKING) {
            if (jitter.value) { jx.update(); jz.update(); jy.update(); }
            float[] a = anglesTo(aimPoint(target));
            wantYaw = a[0]; wantPitch = a[1];
        } else { wantYaw = realYaw; wantPitch = realPitch; }

        spoof = true;
        float step = speed();
        yaw += MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - yaw), -step, step);
        pitch = MathHelper.clamp(pitch + MathHelper.clamp(wantPitch - pitch, -step, step), -90f, 90f);
        if (!Rotations.set(this, yaw, pitch)) { toIdle(); return; }       // another module owns the rotation right now

        // back on the real view: stop spoofing
        if (mode == Mode.FLICKING_AWAY && flickTicks <= 0
                && Math.abs(MathHelper.wrapDegrees(realYaw - yaw)) < 0.5f && Math.abs(realPitch - pitch) < 0.5f) toIdle();
    }

    /** End of the tick (after the movement packet): attack if charged and the server rotation is on the target. */
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mode != Mode.ATTACKING || !spoof || target == null || !target.isAlive()) return;
        if (mc.player.distanceTo(target) > range.value) return;
        if (AutoMaceSwap.progress() < minCharge.value) return;
        if (!aimedAt(target)) return;

        AutoMaceSwap.beforeAttack();
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        AutoMaceSwap.afterAttack();
        if (flick.value) { mode = Mode.FLICKING_AWAY; flickTicks = 2 + rng.nextInt(3); }
    }

    // ----- helpers -------------------------------------------------------------------------------------------
    /** Nearest valid target; ties go to the lower entity id (SilentAuraEntityIdComparator). */
    private LivingEntity pickTarget() {
        LivingEntity best = null; double bd = rotateRange.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(e)) continue;
            double d = mc.player.distanceTo(e);
            if (d < bd || (d == bd && best != null && le.getId() < best.getId())) { bd = d; best = le; }
        }
        return best;
    }

    private boolean valid(Entity e) {
        if (e == mc.player || !e.isAlive()) return false;
        if (e instanceof PlayerEntity p) return players.value && !p.isSpectator() && !Friends.shield(p);
        return e instanceof LivingEntity && mobs.value;
    }

    private Vec3d aimPoint(LivingEntity t) {
        double half = t.getWidth() * 0.5 * 0.8;
        double ox = jitter.value ? MathHelper.clamp(jx.current(), -half, half) : 0;
        double oz = jitter.value ? MathHelper.clamp(jz.current(), -half, half) : 0;
        double oy = jitter.value ? jy.current() : 0;
        return new Vec3d(t.getX() + ox, t.getY() + t.getHeight() * 0.7 + oy, t.getZ() + oz);
    }

    private float[] anglesTo(Vec3d to) {
        Vec3d from = mc.player.getEyePos();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float y = h < 0.35 ? yaw : (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float p = (float) MathHelper.clamp(-Math.toDegrees(Math.atan2(dy, Math.max(h, 1.0E-4))), -90.0, 90.0);
        return new float[]{y, p};
    }

    /** Turn speed this tick (deg): Aim speed x log-normal factor, softer when the target is almost inside you. */
    private float speed() {
        double u1 = Math.max(rng.nextDouble(), 1.0E-4), u2 = rng.nextDouble();
        double gauss = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(Math.PI * 2 * u2);
        double mult = MathHelper.clamp(Math.exp(0.65 + 0.25 * gauss), 1.4, 3.0);
        double s = aimSpeed.value * mult;
        if (mode == Mode.ATTACKING && target != null) {
            double d = mc.player.distanceTo(target);
            if (d < 0.8) s *= Math.max(0.1, d / 0.8);
        }
        return (float) s;
    }

    /** Does the SERVER-side rotation point at the target's hitbox (within range)? */
    private boolean aimedAt(LivingEntity t) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d end = eye.add(Vec3d.fromPolar(pitch, yaw).multiply(range.value + 0.5));
        Box box = t.getBoundingBox().expand(0.05);
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }

    /** Smoothed random offset: every 100-1000 ms picks a new goal in [min,max] and creeps toward it (SilentAuraAimJitter). */
    private static final class AimJitter {
        private final Random r = new Random();
        private final double min, max;
        private double cur, goal;
        private long next;
        AimJitter(double min, double max) { this.min = min; this.max = max; }
        double current() { return cur; }
        void update() {
            long now = System.currentTimeMillis();
            if (now >= next) { next = now + 100 + r.nextInt(900); goal = min + r.nextDouble() * (max - min); }
            if (goal > cur) { cur = Math.min(goal, cur + 0.01 + r.nextDouble() * 0.05); }
            else if (goal < cur) { cur = Math.max(goal, cur - 0.01 - r.nextDouble() * 0.05); }
        }
    }
}
