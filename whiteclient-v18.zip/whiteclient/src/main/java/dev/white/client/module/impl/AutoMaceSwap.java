package dev.white.client.module.impl;

import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.BlockPlacer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import dev.white.client.util.Friends;
import dev.white.client.util.Rotations;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.HitResult;

/**
 * Auto mace swap: the moment you attack, the right mace from your hotbar is selected for the hit, then your
 * original slot comes back (an attribute swap: nothing is held early, so the hit keeps the charge you built up with
 * whatever you were holding). On the ground, or falling less than "Density from" blocks, it uses a Breach mace
 * (armour piercing); once you have fallen that far it uses a Density mace (bonus smash damage per block fallen).
 * Works for your own clicks and for Kill Aura / Trigger Bot hits.
 */
public class AutoMaceSwap extends Module {
    private final Setting.Num densityFrom = add(new Setting.Num("Density from (blocks)", 3, 1, 20, 1));
    private final Setting.Bool fallback = add(new Setting.Bool("Use any mace if none", true));   // no Breach/Density mace in the hotbar
    private final Setting.Bool fromSword = add(new Setting.Bool("Only from sword", false));
    private final Setting.Num delay = add(new Setting.Num("Swap back", 2, 1, 10, 1));            // ticks (your own clicks)
    private final Setting.Bool instant = add(new Setting.Bool("Instant swap back (bots)", true)); // Kill Aura / Trigger Bot

    // Stun slam: axe hit on a blocking player while you fall (shield disabled), then the mace smash
    private final Setting.Bool stunSlam = add(new Setting.Bool("Stun slam", false));
    private final Setting.Num slamMinFall = add(new Setting.Num("Slam min fall (blocks)", 1.5, 0.0, 20.0, 0.5));
    private final Setting.Num slamDelay = add(new Setting.Num("Slam smash delay (ticks)", 0, 0, 6, 1));
    private final Setting.Num slamCharge = add(new Setting.Num("Slam min charge", 0.9, 0.1, 1.0, 0.05));
    private final Setting.Bool slamNeedFall = add(new Setting.Bool("Slam only while falling", true));

    private final Setting.Bool aim = add(new Setting.Bool("Aim at target", false));              // turn toward a player while you fall
    private final Setting.Bool aimSilent = add(new Setting.Bool("Silent aim", false));            // turn what the server sees, not your view
    private final Setting.Num aimRange = add(new Setting.Num("Aim range", 7.0, 3.0, 12.0, 0.5));

    private static final double REACH = 3.0, MIN_HORIZONTAL = 0.35, UPDATES_PER_TICK = 1.875, MAX_ANGLE_PER_TICK = 12.0, MOUSE_UNIT = 0.15;

    private boolean suppress;   // true while the stun slam makes its axe hit, so the axe is not swapped for a mace

    private static AutoMaceSwap instance;
    private int previous = -1, restoreIn;
    private int sinceReset;      // ticks since the last attack / item change (the game keeps this private)
    private Item lastItem;
    private boolean wasDown;     // attack key state last tick, to see a fresh press

    public AutoMaceSwap() {
        super("Auto Mace Swap", Category.COMBAT);
        instance = this;
        // Kill Aura / Trigger Bot hits (and any attack that slipped through): swap right before the attack is sent
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && player == mc.player && entity instanceof net.minecraft.entity.LivingEntity) {
                if (isEnabled() && !suppress) ensureMace();
                sinceReset = 0;                                           // every attack restarts the charge
            }
            return ActionResult.PASS;
        });
    }

    @Override public boolean early() { return true; }       // switch slots before the click is processed this tick
    @Override protected void onEnable() { sinceReset = 0; lastItem = null; }
    @Override protected void onDisable() { restoreNow(); stopAim(); slamFinish(); }

    /**
     * Charge used by Trigger Bot / Kill Aura. This is the charge of the item you are HOLDING (sword...), not the mace's.
     * The attack-speed attribute of a new main-hand item is only applied on the player's next tick, so a hit made in the
     * same tick as the swap is still judged with the old item's cooldown: a fully charged sword gives a fully charged
     * mace hit. Waiting for the mace's own 33-tick charge (what this used to do) just made the bots slow.
     */
    public static float progress() {
        return mc.player.getAttackCooldownProgress(0.5f);
    }

    /**
     * Kill Aura / Trigger Bot call this directly, right before attackEntity. They must not depend on the Fabric
     * AttackEntityCallback: that event is only guaranteed for real clicks, so on aura hits the mace was never selected
     * and the hit went out with the sword. Safe to run together with the callback (the second call changes nothing).
     */
    public static void beforeAttack() {
        if (instance == null || !instance.isEnabled() || mc.player == null || instance.suppress) return;
        instance.ensureMace();
        instance.sinceReset = 0;                                           // the attack restarts the charge
    }

    /**
     * Kill Aura / Trigger Bot call this right after attackEntity. The old slot is sent in the same batch as the hit, so
     * the server never ticks you holding the mace (a tick with the mace in hand would reset your sword's charge).
     */
    public static void afterAttack() {
        if (instance == null || !instance.isEnabled() || !instance.instant.value || instance.previous < 0 || mc.player == null) return;
        int back = instance.previous;
        instance.restoreNow();
        if (mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(back));
    }

    /** Mirrors the game's own charge counter: +1 per tick, back to 0 on an attack or when the held item changes. */
    @Override
    public void onTick() {
        if (mc.player == null) return;
        Item cur = mc.player.getMainHandStack().getItem();
        if (cur != lastItem) { sinceReset = 0; lastItem = cur; }
        else if (sinceReset < 1000) sinceReset++;
        updateAim();
        slamTick();
    }

    // ---------------------------------------------------------------------------------------------------------
    // Stun slam: while you fall with an axe and a mace in the hotbar and your crosshair is on a player blocking with
    // a shield (facing you): select the axe and hit (disables the shield), wait "Slam smash delay" ticks, select the
    // mace and hit (the smash), then put your original slot back.
    // ---------------------------------------------------------------------------------------------------------
    private boolean slamPending;
    private int slamPrev = -1, slamWait;
    private PlayerEntity slamVictim;

    private void slamTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (!stunSlam.value || mc.currentScreen != null || Freecam.active() || mc.player.isSpectator()) { slamFinish(); return; }

        if (slamPending) {
            if (slamVictim == null || !slamVictim.isAlive() || mc.player.distanceTo(slamVictim) > 4.5) { slamFinish(); return; }
            if (++slamWait <= slamDelay.intValue()) return;
            slamSmash();
            slamFinish();
            return;
        }

        if (!(mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult hit) || hit.getType() != HitResult.Type.ENTITY) return;
        if (!(hit.getEntity() instanceof PlayerEntity p) || p == mc.player || !p.isAlive() || p.isSpectator() || Friends.shield(p)) return;
        if (!p.isBlocking()) return;
        Vec3d to = mc.player.getEyePos().subtract(p.getEyePos()).normalize();
        if (p.getRotationVec(1.0f).dotProduct(to) <= 0.0) return;          // a shield only blocks hits from in front
        if (slamNeedFall.value && (mc.player.isOnGround() || mc.player.fallDistance < slamMinFall.value)) return;
        if (progress() < slamCharge.value) return;

        int axe = BlockPlacer.findSlot(s -> !s.isEmpty() && s.isIn(ItemTags.AXES));
        int mace = BlockPlacer.findSlot(s -> s.isOf(Items.MACE));
        if (axe < 0 || mace < 0) return;

        restoreNow();                                                       // drop any swap of our own first
        slamPrev = BlockPlacer.selected();
        BlockPlacer.select(axe);
        suppress = true;
        try {
            mc.interactionManager.attackEntity(mc.player, p);               // syncs the axe slot to the server first
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        } finally { suppress = false; }
        sinceReset = 0;
        slamVictim = p; slamPending = true; slamWait = 0;
        if (slamDelay.intValue() == 0) { slamSmash(); slamFinish(); }      // delay 0: the mace hit goes out in the SAME tick, while you are still in the air
    }

    private void slamSmash() {
        ensureMace();
        if (mc.player.getMainHandStack().isOf(Items.MACE)) {
            mc.interactionManager.attackEntity(mc.player, slamVictim);
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            sinceReset = 0;
        }
    }

    private void slamFinish() {
        if (slamPrev >= 0 && mc.player != null) {
            restoreNow();
            BlockPlacer.select(slamPrev);
            if (mc.getNetworkHandler() != null)
                mc.getNetworkHandler().sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(slamPrev));
        }
        slamPrev = -1; slamPending = false; slamVictim = null; slamWait = 0; suppress = false;
    }

    // ---------------------------------------------------------------------------------------------------------
    // Aim at target: while you fall with a mace, turn toward the nearest player. If the player is already in reach
    // it aims straight at them; otherwise it predicts where both of you will be when you come within reach
    // (impact tick) and only starts turning once the remaining turn needs about that many ticks, so the view
    // arrives right as the hit lands. Turn speed is chosen so the angle is covered in the ticks left. The turn goes
    // through the normal mouse path (your real view moves), no silent rotation.
    // ---------------------------------------------------------------------------------------------------------
    private PlayerEntity aimTarget;
    private boolean committed;
    private double wantYaw, wantPitch, aimSpeed;
    private boolean aimActive;
    private int prevTargetId = -1;
    private Vec3d prevTargetPos;
    private long lastFrameNs;

    private double silYaw, silPitch;

    private void stopAim() { Rotations.release(this); aimTarget = null; aimActive = false; committed = false; prevTargetId = -1; prevTargetPos = null; lastFrameNs = 0; }

    private PlayerEntity pickTarget() {
        PlayerEntity best = null; double bd = aimRange.value;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || Friends.shield(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    private static Vec3d aimPoint(PlayerEntity p) {            // centre of the box, 75% up
        return new Vec3d(p.getX(), p.getY() + p.getHeight() * 0.75, p.getZ());
    }

    private void updateAim() {
        aimActive = false;
        if (!aim.value || mc.world == null || mc.player == null || mc.currentScreen != null
                || Freecam.active() || mc.player.isSpectator()) { stopAim(); return; }
        boolean falling = !mc.player.isOnGround() && !mc.player.isClimbing() && !mc.player.isTouchingWater()
                && mc.player.getVelocity().y < 0.0;
        boolean haveMace = mc.player.getMainHandStack().isOf(Items.MACE) || BlockPlacer.findSlot(s -> s.isOf(Items.MACE)) >= 0;
        if (!falling || !haveMace) { stopAim(); return; }

        PlayerEntity t = pickTarget();
        if (t == null) { stopAim(); return; }
        aimTarget = t;

        Vec3d now = aimPoint(t);
        Vec3d tv = (t.getId() == prevTargetId && prevTargetPos != null) ? now.subtract(prevTargetPos) : Vec3d.ZERO;
        prevTargetId = t.getId(); prevTargetPos = now;

        Vec3d eye = mc.player.getEyePos();
        double curYaw = mc.player.getYaw(), curPitch = mc.player.getPitch();

        if (eye.distanceTo(now) <= REACH) {                      // directly reachable: aim at the target now
            committed = true;
            double[] a = angles(eye, now, curYaw);
            wantYaw = a[0]; wantPitch = a[1];
            aimSpeed = speedForAngle(Math.max(Math.abs(MathHelper.wrapDegrees(a[0] - curYaw)), Math.abs(a[1] - curPitch)), 1);
            aimActive = true;
            return;
        }

        // predict both paths until we are within reach
        Vec3d v = mc.player.getVelocity();
        double vx = v.x, vy = v.y, vz = v.z;
        Vec3d p = eye, tp = now;
        int impact = -1; Vec3d src = null, dst = null;
        for (int k = 1; k <= 20; k++) {
            vy = (vy - 0.08) * 0.98; vx *= 0.91; vz *= 0.91;
            p = p.add(vx, vy, vz);
            tp = tp.add(tv);
            if (p.distanceTo(tp) <= REACH) { impact = k; src = p; dst = tp; break; }
        }
        if (impact < 0) { committed = false; return; }           // no hit in sight: hold the view

        double[] a = angles(src, dst, curYaw);
        double err = Math.max(Math.abs(MathHelper.wrapDegrees(a[0] - curYaw)), Math.abs(a[1] - curPitch));
        int required = Math.max(2, Math.min(4, (int) Math.ceil(err / MAX_ANGLE_PER_TICK) + 1));
        if (committed || impact <= required) {
            committed = true;
            wantYaw = a[0]; wantPitch = a[1];
            aimSpeed = speedForAngle(err, impact - 1);
            aimActive = true;
        }
    }

    private double speedForAngle(double angle, int ticks) {
        double speed = angle / Math.max(UPDATES_PER_TICK * Math.max(ticks, 1), 0.01);
        double max = 75.0 + Math.abs((int) (mc.player.getY() * 100.0) % 5);
        return Math.max(1.0, Math.min(max, speed));
    }

    private static double[] angles(Vec3d from, Vec3d to, double fallbackYaw) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        double yaw = h < MIN_HORIZONTAL ? fallbackYaw : Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double pitch = MathHelper.clamp(-Math.toDegrees(Math.atan2(dy, Math.max(h, 1.0E-4))), -90.0, 90.0);
        return new double[]{yaw, pitch};
    }

    /** Silent aim: one rotation update per tick (before the movement packet), through the shared silent rotation. */
    private void silentAimStep() {
        if (!aim.value || !aimSilent.value || !aimActive) { Rotations.release(this); return; }
        if (!Rotations.ownedBy(this)) { silYaw = mc.player.getYaw(); silPitch = mc.player.getPitch(); }
        double maxStep = aimSpeed * UPDATES_PER_TICK;
        silYaw += MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - silYaw), -maxStep, maxStep);
        silPitch += MathHelper.clamp(wantPitch - silPitch, -maxStep, maxStep);
        Rotations.set(this, (float) silYaw, (float) silPitch);
    }

    /** Every frame: step the view toward the wanted angles (speed is degrees per rotation update, 1.875 updates per tick). */
    @Override
    public void onHud(DrawContext g) {
        if (!aimActive || aimSilent.value || mc.player == null || mc.currentScreen != null) { lastFrameNs = 0; return; }
        long now = System.nanoTime();
        double dt = lastFrameNs == 0 ? 1.0 / 60.0 : (now - lastFrameNs) / 1.0e9;
        lastFrameNs = now;
        dt = MathHelper.clamp(dt, 0.001, 0.05);

        double maxStep = aimSpeed * UPDATES_PER_TICK * 20.0 * dt;
        double errYaw = MathHelper.wrapDegrees(wantYaw - mc.player.getYaw());
        double errPitch = wantPitch - mc.player.getPitch();
        double sy = MathHelper.clamp(errYaw, -maxStep, maxStep);   // never past the target
        double sp = MathHelper.clamp(errPitch, -maxStep, maxStep);
        if (Math.abs(sy) < 1.0e-4 && Math.abs(sp) < 1.0e-4) return;
        mc.player.changeLookDirection(sy / MOUSE_UNIT, sp / MOUSE_UNIT);
    }

    /** Selects the right mace for the current fall (Breach on the ground / short fall, Density from the set height). */
    private void ensureMace() {
        if (mc.player == null) return;
        ItemStack held = mc.player.getMainHandStack();
        if (previous < 0 && fromSword.value && !held.isOf(Items.MACE) && !held.isIn(ItemTags.SWORDS)) return;

        double fallen = mc.player.fallDistance;
        boolean dense = !mc.player.isOnGround() && fallen >= densityFrom.value;
        RegistryKey<Enchantment> want = dense ? Enchantments.DENSITY : Enchantments.BREACH;

        restoreIn = delay.intValue();                                      // keep the mace while the click lasts
        if (held.isOf(Items.MACE) && has(held, want)) return;              // already holding the right one

        int slot = BlockPlacer.findSlot(s -> s.isOf(Items.MACE) && has(s, want));
        if (slot < 0 && fallback.value) {
            if (held.isOf(Items.MACE)) return;                             // keep the mace you already hold
            slot = BlockPlacer.findSlot(s -> s.isOf(Items.MACE));
        }
        if (slot < 0) return;

        if (previous < 0) previous = BlockPlacer.selected();
        BlockPlacer.select(slot);
    }

    private static boolean has(ItemStack s, RegistryKey<Enchantment> key) {
        for (RegistryEntry<Enchantment> e : s.getEnchantments().getEnchantments()) {
            if (e.matchesKey(key)) return true;
        }
        return false;
    }

    /** Manual clicks: swaps the instant you press attack while aiming at an entity, and re-checks every tick (so it moves to Density once you have fallen far enough). */
    @Override
    public void onPreTick() {
        if (mc.player == null || mc.world == null) return;
        silentAimStep();
        boolean onEntity = mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY;
        // Only a FRESH press swaps. Holding the button (Trigger Bot / Aim Assist users do) used to re-swap every tick and keep
        // the mace in hand, so Trigger Bot ended up waiting for the mace's own charge instead of using the sword's.
        boolean down = mc.options.attackKey.isPressed();
        boolean fresh = down && !wasDown;
        wasDown = down;
        boolean clicking = mc.currentScreen == null && onEntity && fresh;
        if (clicking) ensureMace();
        else if (previous >= 0 && --restoreIn <= 0) restoreNow();
    }

    private void restoreNow() {
        if (previous >= 0 && mc.player != null) BlockPlacer.select(previous);
        previous = -1;
    }
}
