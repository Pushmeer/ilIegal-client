package dev.white.client.module.impl;

import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.BlockPlacer;
import dev.white.client.util.Pacing;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Walls yourself in: a block on each of the four sides of your feet (optionally the floor under you and a second
 * ring at head height). Prefers obsidian, otherwise any plain solid hotbar block. Anything that gets broken is put
 * back. Counterpart of Auto Box, which walls in another player.
 */
public class Surround extends Module {
    private static final Direction[] SIDES = { Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST };

    private final Setting.Num perTick = add(new Setting.Num("Blocks/tick", 2, 1, 4, 1));
    private final Setting.Num delay = add(new Setting.Num("Delay", 1, 1, 10, 1));
    private final Setting.Num finish = add(new Setting.Num("Finish time (s)", 2.0, 0.0, 10.0, 0.5));   // seconds the whole action takes; 0 = old instant behaviour (Delay / Blocks per tick)
    private final Setting.Bool head = add(new Setting.Bool("Head level too", false));
    private final Setting.Bool floor = add(new Setting.Bool("Floor under feet", false));
    private final Setting.Bool onGround = add(new Setting.Bool("Only on ground", true));
    private final Setting.Bool stayPut = add(new Setting.Bool("Off if I move", true));
    private final Setting.Bool obsidianOnly = add(new Setting.Bool("Obsidian only", false));

    private int wait, restore = -1;
    private BlockPos anchor;

    public Surround() { super("Surround", Category.COMBAT); }

    @Override
    protected void onEnable() {
        wait = 0;
        restore = -1;
        anchor = mc.player != null ? mc.player.getBlockPos() : null;
    }

    @Override protected void onDisable() { restoreSlot(); anchor = null; }

    private void restoreSlot() {
        if (restore >= 0 && mc.player != null) BlockPlacer.select(restore);
        restore = -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null || Freecam.active()) return;
        BlockPos feet = mc.player.getBlockPos();
        if (anchor == null) anchor = feet;
        if (!feet.equals(anchor)) {
            if (stayPut.value) { setEnabled(false); return; }
            anchor = feet;                                           // follow the player
        }
        if (onGround.value && !mc.player.isOnGround()) return;

        int slot = BlockPlacer.findSlot(s -> s.isOf(Items.OBSIDIAN));
        if (slot < 0 && !obsidianOnly.value) slot = BlockPlacer.findSlot(BlockPlacer::isSolidBlock);
        if (slot < 0) { restoreSlot(); return; }

        // floor first, then the ring around the feet, then the ring at head height, so every block has support
        List<BlockPos> spots = new ArrayList<>();
        if (floor.value) spots.add(feet.down());
        for (Direction d : SIDES) spots.add(feet.offset(d));
        if (head.value) for (Direction d : SIDES) spots.add(feet.up().offset(d));

        List<BlockPos> need = new ArrayList<>();
        for (BlockPos p : spots) {
            if (!mc.world.getBlockState(p).isReplaceable()) continue;                       // already filled
            Box b = new Box(p);
            if (!mc.world.getOtherEntities(null, b, e -> e instanceof LivingEntity && !e.isSpectator()).isEmpty()) continue;   // you / a mob is in the way
            need.add(p);
        }
        if (need.isEmpty()) { wait = 0; restoreSlot(); return; }                            // nothing to do: the next job starts a fresh timer
        if (++wait < Pacing.gap(finish.value, spots.size(), delay.intValue())) return;      // paced: one block every finish/N seconds

        int per = Pacing.perStep(finish.value, perTick.intValue());
        int placed = 0;
        for (BlockPos p : need) {
            if (restore < 0) restore = BlockPlacer.selected();
            BlockPlacer.select(slot);
            if (BlockPlacer.place(p) && ++placed >= per) break;
        }
        if (placed > 0) { wait = 0; if (Pacing.paced(finish.value)) restoreSlot(); } else restoreSlot();
    }
}
