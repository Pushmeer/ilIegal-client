package dev.white.client.mixin;

import dev.white.client.util.Rotations;
import net.minecraft.entity.Entity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Silent rotation (util/Rotations): the movement packet carries the server-side rotation; your own view is put back right after. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique private float white$realYaw, white$realPitch;
    @Unique private boolean white$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"), require = 0)
    private void white$silentHead(CallbackInfo ci) {
        if (!Rotations.active()) return;
        Entity e = (Entity) (Object) this;
        white$realYaw = e.getYaw();
        white$realPitch = e.getPitch();
        e.setYaw(Rotations.yaw());
        e.setPitch(Rotations.pitch());
        white$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"), require = 0)
    private void white$silentReturn(CallbackInfo ci) {
        if (!white$swapped) return;
        Entity e = (Entity) (Object) this;
        e.setYaw(white$realYaw);
        e.setPitch(white$realPitch);
        white$swapped = false;
    }
}
