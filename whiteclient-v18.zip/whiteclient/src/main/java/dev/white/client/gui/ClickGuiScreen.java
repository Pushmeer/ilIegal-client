package dev.white.client.gui;

import dev.white.client.util.SdfText;
import dev.white.client.WhiteClient;
import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.Ui;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Draggable category windows with module toggles and dropdown settings.
 * Left click = toggle / use, right click = open settings (or collapse a window),
 * middle click = bind a key, drag a title bar to move a window. RIGHT SHIFT closes.
 */
public class ClickGuiScreen extends Screen implements ModuleGui {

    /**
     * Resolution: the whole menu is laid out on a grid M times finer than a GUI pixel (text is drawn M times bigger,
     * every size below is M x the old one) and then scaled back down, so edges, text and shapes can sit on every
     * screen pixel instead of every GUI pixel. All the numbers below are in these fine units.
     */
    private static final int M = 2;
    private static final float FS = 10f * M;   // text size in fine units

    private static final int W = 118 * M, TITLE_H = 24 * M, ROW_H = 20 * M, SET_H = 18 * M, NUM_H = 28 * M,
            STRIP_X = 40 * M, STRIP_END = 18 * M, R = 3 * M, VISIBLE_ROWS = 11, GUT = 6 * M;   // GUT = room kept free for the scrollbar
    private static final int NAV_W = 96 * M, NAV_X = 8 * M, NAV_Y = 34 * M, NAV_HEAD = 26 * M, NAV_ROW = 20 * M;

    // ---- dark "vape" palette: near-black panels, white = enabled ----
    private static final int C_BODY   = 0xF2090909;
    private static final int C_HOVER  = 0xFF1B1B1B;
    private static final int C_SET    = 0xFF131313;
    private static final int C_TEXT   = 0xFFE2E2E2;
    private static final int C_MUTED  = 0xFF7C7C7C;
    private static final int C_TRACK  = 0xFF303030;
    private static final int C_DARK   = 0xFF0E0E0E;
    private static final int C_LINE   = 0xFF222222;

    /** Accent used for enabled rows / sliders / switches: white unless the HUD tint is turned on. */
    private static int accent() {
        float s = dev.white.client.module.impl.Hud.saturation();
        if (s < 0.2f) return 0xFFFFFFFF;
        return 0xFF000000 | MathHelper.hsvToRgb(dev.white.client.module.impl.Hud.hue(), 0.65f * s, 1f);
    }

    /** Text colour that stays readable on the accent. */
    private static int onAccent(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return (0.299 * r + 0.587 * g + 0.114 * b) > 140 ? 0xFF0B0B0B : 0xFFFFFFFF;
    }

    private static final int WHEEL_H = 104 * M, WS = 64 * M, BAR_DY = 90 * M, BAR_H = 8 * M;

    private static int settingH(Setting s) {
        if (s instanceof Setting.Hue h && h.wheel) return WHEEL_H;
        return s instanceof Setting.Num ? NUM_H : SET_H;
    }

    // ---- text in fine units ----
    private static int tw(String s) { return (int) Math.ceil(SdfText.width(SdfText.Face.SANS, s, FS)); }
    private static void tx(DrawContext g, String s, int x, int y, int c) { SdfText.draw(g, SdfText.Face.SANS, s, x, y, FS, c); }
    private static String trim(String s, int max, boolean fromEnd) {
        if (tw(s) <= max) return s;
        String t = s;
        while (!t.isEmpty() && tw(t) > max) t = fromEnd ? t.substring(1) : t.substring(0, t.length() - 1);
        return t;
    }

    /** Where each colour-wheel row was last drawn (x, y, row width), so a click can be turned into a hue / saturation / brightness. */
    private final java.util.Map<Setting, int[]> wheelGeom = new java.util.HashMap<>();
    private int dragPart;   // 0 = slider / hue strip, 1 = colour wheel, 2 = brightness bar
    private int wheelCx, wheelCy, barX, barW;
    private static final List<Win> WINS = new ArrayList<>(); // static: positions survive reopening
    private static int placedKey;
    private static boolean placed;                          // windows are centred in a row the first time the menu opens

    private record Hit(int x, int y, int w, int h, int kind, Module module, Setting setting) {
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private static class Win {
        final Category cat; int x, y; boolean open = true; int scroll, maxScroll, gut; float pos, target;
        final List<Hit> hits = new ArrayList<>();
        Win(Category cat, int x, int y) { this.cat = cat; this.x = x; this.y = y; }
    }

    private Win dragWin;
    private int dragDx, dragDy;
    private Setting activeSlider;
    private int sliderX, sliderW;
    private Module listening;
    private Setting.Text typing;   // text box that has keyboard focus (Friends: type a name, Enter)
    private String query = "";
    private int lastMx, lastMy;
    private float ease = 1f;    // smooth scrolling speed for this frame
    private long lastNs;
    private String hoverFull;   // full text of a setting label that had to be shortened, shown while hovering it

    /** Shortens text with "..." so it always fits in max units. */
    private String fit(String s, int max) {
        if (tw(s) <= max) return s;
        String dots = "...";
        return trim(s, Math.max(0, max - tw(dots)), false) + dots;
    }

    /** Hue rows show the label without a trailing "color" and move the strip right for longer labels. */
    private static String hueLabel(Setting.Hue h) {
        String t = h.name.replaceAll("(?i)\\s+colou?r$", "");
        return t.isEmpty() ? h.name : t;
    }

    private int hueStart(Setting.Hue h) {
        return Math.max(STRIP_X, 9 * M + tw(hueLabel(h)) + 5 * M);
    }

    public ClickGuiScreen() {
        super(Text.literal(dev.white.client.module.impl.Hud.NAME));
        if (WINS.isEmpty()) {
            int i = 0;
            for (Category c : Category.values()) WINS.add(new Win(c, NAV_X + NAV_W + 10 * M + i++ * (W + 8 * M), NAV_Y));
        }
    }

    @Override
    protected void init() {
        fitScale();
        int key = width * 10000 + height;
        if (placedKey != key) placed = false;
        if (placed || WINS.isEmpty()) return;
        placedKey = key;
        int n = WINS.size(), gap = 8 * M, total = n * W + (n - 1) * gap;
        int left = NAV_X + NAV_W + 10 * M;
        int sx = left + Math.max(0, (vw() - left - 4 * M - total) / 2);
        int sy = Math.max(26 * M, NAV_Y);
        for (int i = 0; i < n; i++) { Win w = WINS.get(i); w.x = sx + i * (W + gap); w.y = sy; }
        placed = true;
    }

    /** True while waiting for a key to bind (so Right Shift can be bound instead of closing). */
    @Override public boolean isBinding() { return listening != null || typing != null; }

    @Override public boolean shouldPause() { return false; }

    // the game's own menu blur (HUD -> Menu blur); with it off the world stays sharp behind the windows
    @Override public void renderBackground(DrawContext g, int mx, int my, float delta) {
        if (dev.white.client.module.impl.Hud.menuBlur()) super.renderBackground(g, mx, my, delta);
    }

    // ---- scale: GUI pixels per fine unit. Always a whole number of SCREEN pixels per unit, so nothing is ever blurry ----
    private float uiScale = 1f / M;

    private void fitScale() {
        float fit = Math.min(1f, Math.min(width / 880f, height / 330f));   // 1 = the menu at its normal size
        float ideal = fit / M;
        double gs = client != null && client.getWindow() != null ? client.getWindow().getScaleFactor() : 1.0;
        double px = Math.max(1.0, Math.floor(ideal * gs));                 // screen pixels per unit
        float eff = (float) (px / gs);
        if (eff * 880f * M > width + 1 || eff * 330f * M > height + 1) eff = ideal;   // tiny windows: fit first, snap second
        uiScale = eff;
    }

    /** Menu-space size of the screen in fine units. */
    private int vw() { return Math.round(width / uiScale); }
    private int vh() { return Math.round(height / uiScale); }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        fitScale();
        var mat = g.getMatrices();
        mat.pushMatrix();
        mat.scale(uiScale, uiScale);
        try { renderScaled(g, Math.round(mx / uiScale), Math.round(my / uiScale), delta); }
        finally { mat.popMatrix(); }
    }

    private void renderScaled(DrawContext g, int mx, int my, float delta) {
        dev.white.client.module.impl.Hud.applyTheme();
        dev.white.client.module.impl.Snowflakes.draw(g, vw(), vh());   // behind the windows; no-op unless the module is on
        lastMx = mx; lastMy = my; hoverFull = null;
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        ease = 1f - (float) Math.exp(-dt * 18f);
        for (Win w : WINS) {   // keep every window on screen after a GUI scale / resolution change
            w.x = MathHelper.clamp(w.x, 0, Math.max(0, vw() - W));
            w.y = MathHelper.clamp(w.y, 0, Math.max(0, vh() - TITLE_H));
        }
        for (Win w : WINS) drawWindow(g, w, mx, my);
        drawNav(g, mx, my);
        drawSearch(g);
        drawPalette(g);
        if (hoverFull != null) {                                          // full label of a shortened setting
            int tipW = tw(hoverFull) + 16;
            int tipX = Math.max(4, Math.min(mx + 20, vw() - tipW - 4)), tipY = Math.max(4, Math.min(my + 24, vh() - 28));
            Ui.corners(g, tipX, tipY, tipX + tipW, tipY + 24, 6, 0xFF000000, true, true, true, true);
            Ui.outline(g, tipX, tipY, tipX + tipW, tipY + 24, C_TRACK);
            tx(g, hoverFull, tipX + 8, tipY + 4, C_TEXT);
        }
    }

    // palette button (bottom right) and search bar (bottom centre)
    private static final int PAL = 20 * M;
    private int palX() { return vw() - PAL - 8 * M; }
    private int palY() { return vh() - PAL - 8 * M; }
    private int searchY() { return vh() - 38 * M; }
    private static final int SEARCH_W = 130 * M;

    private static void dots(DrawContext g, int cx, int cy, int c) {
        for (int i = -1; i <= 1; i++) g.fill(cx - 2, cy + i * 8 - 2, cx + 2, cy + i * 8 + 2, c);
    }

    /** Small "^" (up) or "v" (down) drawn from pixels. */
    private static void caret(DrawContext g, int cx, int cy, boolean up, int c) {
        for (int r = 0; r < 4; r++) {
            int yy = up ? cy - 4 + 2 * r : cy + 2 - 2 * r;
            g.fill(cx - 2 * r - 2, yy, cx - 2 * r, yy + 2, c);
            g.fill(cx + 2 * r, yy, cx + 2 * r + 2, yy + 2, c);
        }
    }

    /** Left panel: client name + one row per category. Click a row to open that window and bring it to the front. */
    private void drawNav(DrawContext g, int mx, int my) {
        Category[] cats = Category.values();
        int h = NAV_HEAD + cats.length * NAV_ROW + 6 * M;
        Ui.corners(g, NAV_X, NAV_Y, NAV_X + NAV_W, NAV_Y + h, R, C_BODY, true, true, true, true);
        SdfText.draw(g, SdfText.Face.BOLD, dev.white.client.module.impl.Hud.NAME, NAV_X + 9 * M, NAV_Y + 8 * M, 9f * M, 0xFFFFFFFF);
        g.fill(NAV_X, NAV_Y + NAV_HEAD - 2, NAV_X + NAV_W, NAV_Y + NAV_HEAD, C_LINE);
        int acc = accent();
        for (int i = 0; i < cats.length; i++) {
            int ry = NAV_Y + NAV_HEAD + i * NAV_ROW;
            boolean hover = mx >= NAV_X && mx < NAV_X + NAV_W && my >= ry && my < ry + NAV_ROW;
            if (hover) g.fill(NAV_X, ry, NAV_X + NAV_W, ry + NAV_ROW, C_HOVER);
            int on = 0;
            for (Module m : WhiteClient.modules.inCategory(cats[i])) if (m.isEnabled()) on++;
            tx(g, cats[i].label, NAV_X + 10 * M, ry + 6 * M, C_TEXT);
            if (on > 0) { String c = String.valueOf(on); tx(g, c, NAV_X + NAV_W - 22 * M - tw(c), ry + 6 * M, acc); }
            for (int k = 0; k < 4; k++) {   // ">" arrow
                g.fill(NAV_X + NAV_W - 14 * M + 2 * k, ry + 7 * M + 2 * k, NAV_X + NAV_W - 14 * M + 2 * k + 2, ry + 7 * M + 2 * k + 2, C_MUTED);
                g.fill(NAV_X + NAV_W - 14 * M + 2 * k, ry + 13 * M - 2 * k, NAV_X + NAV_W - 14 * M + 2 * k + 2, ry + 13 * M - 2 * k + 2, C_MUTED);
            }
        }
    }

    private int navRowAt(double mx, double my) {
        Category[] cats = Category.values();
        if (mx < NAV_X || mx >= NAV_X + NAV_W) return -1;
        int rel = (int) my - (NAV_Y + NAV_HEAD);
        if (rel < 0 || rel >= cats.length * NAV_ROW) return -1;
        return rel / NAV_ROW;
    }

    private void drawPalette(DrawContext g) {
        int px = palX(), py = palY();
        Ui.corners(g, px, py, px + PAL, py + PAL, R, C_BODY, true, true, true, true);
        Ui.corners(g, px + 8, py + 8, px + 18, py + 18, 4, 0xFFFFFFFF, true, true, true, true);
        Ui.corners(g, px + 22, py + 8, px + 32, py + 18, 4, 0xFFB8B8B8, true, true, true, true);
        Ui.corners(g, px + 8, py + 22, px + 18, py + 32, 4, 0xFF7A7A7A, true, true, true, true);
        Ui.corners(g, px + 22, py + 22, px + 32, py + 32, 4, 0xFF404040, true, true, true, true);
    }

    /** Search bar at the bottom centre: just start typing. Filters every window to the matching modules. */
    private void drawSearch(DrawContext g) {
        int sw = SEARCH_W, sx = (vw() - sw) / 2, sy = searchY();
        Ui.corners(g, sx, sy, sx + sw, sy + 36, R, C_BODY, true, true, true, true);
        if (!query.isEmpty()) Ui.outline(g, sx, sy, sx + sw, sy + 36, accent());
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (query.isEmpty()) {
            tx(g, "Search...", sx + 18, sy + 10, C_MUTED);
        } else {
            String shown = trim(query, sw - 56, true);
            tx(g, shown + (blink ? "_" : ""), sx + 18, sy + 10, C_TEXT);
            tx(g, "x", sx + sw - 22, sy + 10, C_MUTED);
        }
    }

    private boolean matches(Module m) {
        return query.isEmpty() || m.name.toLowerCase().contains(query.toLowerCase());
    }

    private void drawWindow(DrawContext g, Win w, int mx, int my) {
        w.hits.clear();
        w.pos += (w.target - w.pos) * ease;
        if (Math.abs(w.target - w.pos) < 0.5f) w.pos = w.target;
        w.scroll = Math.round(w.pos);
        int x = w.x, y = w.y;
        boolean any = false;
        for (Module m : WhiteClient.modules.inCategory(w.cat)) if (matches(m)) { any = true; break; }
        if (!any) return;   // nothing in this window matches the search

        boolean showRows = w.open || !query.isEmpty();
        int viewTop = y + TITLE_H;
        int viewBot = Math.min(Math.max(viewTop + ROW_H, vh() - 44 * M), viewTop + VISIBLE_ROWS * ROW_H + 4 * M);
        int contentH = R;   // bottom margin: rows stop short of the rounded corners
        for (Module m : WhiteClient.modules.inCategory(w.cat)) {
            if (!matches(m)) continue;
            contentH += ROW_H;
            if (m.expanded) for (Setting st : m.settings) contentH += settingH(st);
        }
        int bodyH = showRows ? Math.min(contentH, viewBot - viewTop) : 0;
        int bottom = viewTop + bodyH;
        int acc = accent();
        boolean scrolls = contentH > bodyH;
        w.gut = scrolls ? GUT : 0;         // enabled rows / settings end before the scrollbar instead of running under it
        int rowW = W - w.gut;

        // flat near-black window
        Ui.corners(g, x, y, x + W, bottom, R, C_BODY, true, true, true, true);

        // header: icon, title on the left, caret on the right (click = fold / unfold)
        int iy = y + TITLE_H / 2 - 7;
        for (int i = 0; i < 3; i++) g.fill(x + 18, iy + i * 6, x + 34, iy + i * 6 + 2, 0xFFFFFFFF);
        tx(g, w.cat.label, x + 48, y + (TITLE_H - 16) / 2, 0xFFFFFFFF);
        caret(g, x + W - 26, y + TITLE_H / 2, showRows, C_MUTED);
        w.hits.add(new Hit(x, y, W, TITLE_H, 0, null, null));

        if (!showRows) { w.maxScroll = 0; return; }

        int cy = viewTop - w.scroll;
        g.enableScissor(x, viewTop, x + W, viewTop + bodyH - R);   // rows never reach the bottom corners
        for (Module m : WhiteClient.modules.inCategory(w.cat)) {
            if (!matches(m)) continue;
            boolean hover = mx >= x && mx < x + rowW && my >= Math.max(cy, viewTop) && my < Math.min(cy + ROW_H, viewTop + bodyH - R) && my >= cy;
            boolean on = m.isEnabled();
            if (on) g.fill(x, cy, x + rowW, cy + ROW_H, acc);              // enabled module: solid white row
            else if (hover) g.fill(x, cy, x + rowW, cy + ROW_H, C_HOVER);
            int fg = on ? onAccent(acc) : C_TEXT;
            int sub = on ? (onAccent(acc) & 0x00FFFFFF | 0xB0000000) : C_MUTED;
            int right = x + rowW - 18;
            if (!m.settings.isEmpty()) { dots(g, x + rowW - 20, cy + ROW_H / 2, sub); right = x + rowW - 40; }
            String tag = listening == m ? "..." : m.key > 0 ? "[" + keyName(m.key) + "]" : "";
            int tagW = tag.isEmpty() ? 0 : tw(tag) + 6;
            if (!tag.isEmpty()) tx(g, tag, right - tagW + 6, cy + 12, sub);
            String shownName = fit(m.name, right - tagW - (x + 20));
            tx(g, shownName, x + 20, cy + 12, fg);
            if (hover && !shownName.equals(m.name)) hoverFull = m.name;

            if (cy + ROW_H > viewTop && cy < viewTop + bodyH) w.hits.add(new Hit(x, Math.max(cy, viewTop), rowW, ROW_H - Math.max(0, viewTop - cy), 1, m, null));
            cy += ROW_H;
            if (m.expanded) {
                for (Setting st : m.settings) {
                    int sh = settingH(st);
                    if (cy + sh > viewTop && cy < viewTop + bodyH) drawSetting(g, w, m, st, x, cy, sh, rowW, viewTop);
                    cy += sh;
                }
            }
        }
        g.disableScissor();
        w.maxScroll = Math.max(0, contentH - bodyH);
        w.target = MathHelper.clamp(w.target, 0, w.maxScroll);
        w.pos = MathHelper.clamp(w.pos, 0, w.maxScroll);
        w.scroll = Math.round(w.pos);
        if (w.maxScroll > 0) {   // scrollbar lives in its own gutter on the right
            int trackH = bodyH - R;
            int th = Math.max(20, trackH * trackH / contentH);
            int ty = viewTop + (int) ((trackH - th) * (w.scroll / (double) w.maxScroll));
            Ui.corners(g, x + W - 9, ty, x + W - 5, ty + th, 2, 0xFF4A4A4A, true, true, true, true);
        }
    }

    private void drawSetting(DrawContext g, Win w, Module m, Setting s, int x, int y, int h, int rowW, int viewTop) {
        int acc = accent();
        g.fill(x, y, x + rowW, y + h, C_SET);
        boolean over = lastMy >= viewTop && lastMx >= x && lastMx < x + rowW && lastMy >= y && lastMy < y + h;
        int ty = y + (SET_H - 16) / 2;
        if (s instanceof Setting.Bool b) {
            String shown = fit(b.name, rowW - 88);                 // label area ends before the switch
            tx(g, shown, x + 20, ty, C_TEXT);
            if (over && !shown.equals(b.name)) hoverFull = b.name;
            int bx = x + rowW - 52, by = y + (h - 16) / 2;          // pill switch
            Ui.corners(g, bx, by, bx + 32, by + 16, 8, b.value ? acc : C_TRACK, true, true, true, true);
            int kx = b.value ? bx + 18 : bx + 2;
            Ui.corners(g, kx, by + 2, kx + 12, by + 14, 6, b.value ? onAccent(acc) : 0xFF8A8A8A, true, true, true, true);
        } else if (s instanceof Setting.Num n) {
            // label left, value right, thin slider with a round knob underneath
            String v = n.step >= 1 ? String.valueOf(n.intValue()) : String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.value);
            int valW = tw(v);
            String shown = fit(n.name, rowW - 56 - valW);
            tx(g, shown, x + 20, y + 10, C_TEXT);
            tx(g, v, x + rowW - 20 - valW, y + 10, C_TEXT);
            if (over && !shown.equals(n.name)) hoverFull = n.name + ": " + v;
            int sx = x + 20, sw = rowW - 40, ly = y + h - 16;
            Ui.corners(g, sx, ly - 2, sx + sw, ly + 2, 2, C_TRACK, true, true, true, true);
            int kx = sx + (int) Math.round(n.fraction() * sw);
            if (kx > sx) Ui.corners(g, sx, ly - 2, kx, ly + 2, 2, acc, true, true, true, true);
            Ui.corners(g, kx - 6, ly - 6, kx + 6, ly + 6, 6, acc, true, true, true, true);
        } else if (s instanceof Setting.Hue hu && hu.wheel) {
            tx(g, hueLabel(hu), x + 20, ty, C_TEXT);
            Ui.corners(g, x + rowW - 52, y + 8, x + rowW - 20, y + SET_H - 8, 6, hu.argb(255), true, true, true, true);
            int top = y + SET_H + 4, cx = x + rowW / 2, cy = top + WS / 2;
            wheelGeom.put(s, new int[]{x, y, rowW});
            Ui.wheel(g, cx - WS / 2, top, cx + WS / 2, top + WS, hu.val);
            // picker knob: ring around the chosen colour
            double ang = (hu.hue - 0.5) * Math.PI * 2.0;
            int kx = cx + (int) Math.round(Math.cos(ang) * hu.sat * (WS / 2 - 2));
            int ky = cy + (int) Math.round(Math.sin(ang) * hu.sat * (WS / 2 - 2));
            Ui.corners(g, kx - 8, ky - 8, kx + 8, ky + 8, 8, 0xFFFFFFFF, true, true, true, true);
            Ui.corners(g, kx - 6, ky - 6, kx + 6, ky + 6, 6, hu.argb(255), true, true, true, true);
            // brightness bar: black -> the chosen colour at full brightness
            int bx = x + 20, bw = rowW - 40, by = y + BAR_DY;
            int full = 0xFF000000 | (MathHelper.hsvToRgb(hu.hue, hu.sat, 1f) & 0xFFFFFF);
            Ui.corners(g, bx, by, bx + bw, by + BAR_H, 8, 0xFF000000, true, true, true, true);
            Ui.gradient(g, bx, by, bx + bw, by + BAR_H, 8, 0xFF000000, full);
            int bk = bx + Math.round(hu.val * bw);
            Ui.corners(g, bk - 6, by - 2, bk + 6, by + BAR_H + 2, 6, 0xFFFFFFFF, true, true, true, true);
        } else if (s instanceof Setting.Hue hu) {
            tx(g, hueLabel(hu), x + 20, ty, C_TEXT);
            int off = hueStart(hu);
            int sx = x + off, sw = rowW - off - STRIP_END;
            Ui.hueStrip(g, sx, y + 10, sx + sw, y + h - 12, 4);   // rainbow drawn by a shader
            int mxp = sx + (int) (hu.hue * sw);
            g.fill(mxp - 2, y + 6, mxp + 2, y + h - 8, 0xFFFFFFFF);
            Ui.corners(g, x + rowW - 32, y + 10, x + rowW - 16, y + h - 12, 4, hu.argb(255), true, true, true, true);
        } else if (s instanceof Setting.Text t) {
            boolean focus = typing == t;
            Ui.corners(g, x + 12, y + 4, x + rowW - 12, y + h - 4, 6, C_DARK, true, true, true, true);
            if (focus) Ui.outline(g, x + 12, y + 4, x + rowW - 12, y + h - 4, acc);
            String caret = focus && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "";
            if (t.value.isEmpty()) {
                tx(g, fit(t.name, rowW - 52), x + 20, ty, C_MUTED);
                if (!caret.isEmpty()) tx(g, caret, x + 20, ty, C_TEXT);
            } else {
                tx(g, trim(t.value, rowW - 52, true) + caret, x + 20, ty, C_TEXT);
            }
        } else if (s instanceof Setting.Button btn) {
            Ui.corners(g, x + 12, y + 4, x + rowW - 12, y + h - 4, 6, over ? 0xFF262626 : 0xFF1C1C1C, true, true, true, true);
            String shown = fit(btn.name, rowW - 48);
            tx(g, shown, x + (rowW - tw(shown)) / 2, ty, C_TEXT);
            if (over && !shown.equals(btn.name)) hoverFull = btn.name;
        }
        int hy = Math.max(y, viewTop);
        w.hits.add(new Hit(x, hy, rowW, h - (hy - y), 2, m, s));
    }

    // ---------------- input ----------------

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x() / uiScale, my = click.y() / uiScale;
        int button = click.button();
        typing = null;   // clicking anywhere drops text focus; clicking a text box again (see handle) re-focuses it
        int sw = SEARCH_W, sx = (vw() - sw) / 2, sy = searchY();
        int nav = navRowAt(mx, my);
        if (nav >= 0) {   // category in the left panel: unfold its window and bring it to the front
            Category c = Category.values()[nav];
            for (int i = 0; i < WINS.size(); i++) if (WINS.get(i).cat == c) {
                Win w = WINS.remove(i); w.open = true; WINS.add(w); break;
            }
            return true;
        }
        if (mx >= palX() && mx < palX() + PAL && my >= palY() && my < palY() + PAL) {
            if (button == 1) dev.white.client.module.impl.Hud.resetAccent(); else dev.white.client.module.impl.Hud.cycleAccent();
            return true;
        }
        if (!query.isEmpty() && mx >= sx + sw - 32 && mx < sx + sw && my >= sy && my < sy + 36) { query = ""; return true; }
        for (int i = WINS.size() - 1; i >= 0; i--) {
            Win w = WINS.get(i);
            for (Hit h : w.hits) {
                if (h.contains(mx, my)) {
                    WINS.remove(i);
                    WINS.add(w);          // bring to front
                    handle(w, h, button, mx, my);
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void handle(Win w, Hit h, int button, double mx, double my) {
        switch (h.kind()) {
            case 0 -> {
                if (button == 0 && (mx < h.x() + 44 || mx >= h.x() + W - 44)) w.open = !w.open;   // icon / caret folds the window
                else if (button == 0) { dragWin = w; dragDx = (int) mx - w.x; dragDy = (int) my - w.y; }
                else if (button == 1) w.open = !w.open;
            }
            case 1 -> {
                Module m = h.module();
                if (button == 0 && !m.settings.isEmpty() && mx >= h.x() + h.w() - 40) m.expanded = !m.expanded;   // three dots open the settings
                else if (button == 0) m.toggle();
                else if (button == 1 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                else if (button == 2) listening = m;
            }
            case 2 -> {
                if (button != 0) return;
                Setting s = h.setting();
                if (s instanceof Setting.Bool b) b.value = !b.value;
                else if (s instanceof Setting.Button btn) btn.action.run();
                else if (s instanceof Setting.Text t) typing = t;
                else if (s instanceof Setting.Num) { dragPart = 0; startSlider(s, h.x() + 20, h.w() - 40, mx); }
                else if (s instanceof Setting.Hue hue && hue.wheel) startWheel(hue, mx, my);
                else if (s instanceof Setting.Hue hue) { int off = hueStart(hue); dragPart = 0; startSlider(s, h.x() + off, h.w() - off - STRIP_END, mx); }
            }
            default -> {}
        }
    }

    private void startSlider(Setting s, int x, int w, double mx) {
        activeSlider = s; sliderX = x; sliderW = w;
        applySlider(mx, lastMy);
    }

    private void startWheel(Setting.Hue hu, double mx, double my) {
        int[] gm = wheelGeom.get(hu);
        if (gm == null || my < gm[1] + SET_H) return;          // the label row does nothing
        activeSlider = hu;
        wheelCx = gm[0] + gm[2] / 2;
        wheelCy = gm[1] + SET_H + 4 + WS / 2;
        barX = gm[0] + 20; barW = gm[2] - 40;
        dragPart = my >= gm[1] + BAR_DY - 10 ? 2 : 1;           // bottom strip = brightness, above it = wheel
        applySlider(mx, my);
    }

    private void applySlider(double mx, double my) {
        if (activeSlider instanceof Setting.Num n) n.setFraction((mx - sliderX) / sliderW);
        else if (activeSlider instanceof Setting.Hue h) {
            if (!h.wheel || dragPart == 0) h.hue = (float) MathHelper.clamp((mx - sliderX) / sliderW, 0.0, 0.999);
            else if (dragPart == 2) h.val = (float) MathHelper.clamp((mx - barX) / barW, 0.03, 1.0);
            else {
                double dx = mx - wheelCx, dy = my - wheelCy, r = WS / 2.0 - 2;
                h.hue = (float) MathHelper.clamp(Math.atan2(dy, dx) / (Math.PI * 2.0) + 0.5, 0.0, 0.999);
                h.sat = (float) MathHelper.clamp(Math.hypot(dx, dy) / r, 0.0, 1.0);
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        mx /= uiScale; my /= uiScale;
        for (int i = WINS.size() - 1; i >= 0; i--) {
            Win w = WINS.get(i);
            if (!(w.open || !query.isEmpty()) || w.maxScroll <= 0) continue;
            if (mx >= w.x && mx < w.x + W && my >= w.y && my < vh()) {
                w.target = MathHelper.clamp(w.target - (float) vAmount * 60f, 0, w.maxScroll);
                return true;
            }
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragWin != null) {
            dragWin.x = MathHelper.clamp((int) (click.x() / uiScale) - dragDx, 0, Math.max(0, vw() - W));
            dragWin.y = MathHelper.clamp((int) (click.y() / uiScale) - dragDy, 0, Math.max(0, vh() - TITLE_H));
            return true;
        }
        if (activeSlider != null) { applySlider(click.x() / uiScale, click.y() / uiScale); return true; }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragWin = null;
        activeSlider = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (typing != null) {
            int cp = input.codepoint();
            if (typing.value.length() < 32 && !Character.isISOControl(cp) && !Character.isWhitespace(cp))
                typing.value += new String(Character.toChars(cp));
            return true;
        }
        if (listening != null) return false;
        String t = new String(Character.toChars(input.codepoint()));
        if (t.isBlank() && query.isEmpty()) return true;
        if (query.length() < 32 && !Character.isISOControl(input.codepoint())) {
            query += t;
            for (Win w : WINS) { w.scroll = 0; w.pos = 0; w.target = 0; }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.getKeycode();
        if (typing != null) {   // a text box has focus: it gets every key (Right Shift included)
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) typing.submit();
            else if (key == GLFW.GLFW_KEY_ESCAPE) typing = null;
            else if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!typing.value.isEmpty()) typing.value = typing.value.substring(0, typing.value.length() - 1); }
            else if (key == GLFW.GLFW_KEY_V && client != null && client.getWindow() != null
                    && (GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS)) {
                String clip = GLFW.glfwGetClipboardString(client.getWindow().getHandle());   // Ctrl+V
                if (clip != null) for (char ch : clip.toCharArray())
                    if (!Character.isISOControl(ch) && !Character.isWhitespace(ch) && typing.value.length() < 32) typing.value += ch;
            }
            return true;
        }
        if (listening == null && !query.isEmpty()) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { query = query.substring(0, query.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE) { query = ""; return true; }
        }
        if (listening != null) {
            boolean clear = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE;
            listening.key = clear ? -1 : key;
            listening = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { WhiteClient.modules.consumeGuiKey(); close(); return true; }
        return super.keyPressed(input);
    }

    private static String keyName(int key) {
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null ? n.toUpperCase() : "K" + key;
    }
}
