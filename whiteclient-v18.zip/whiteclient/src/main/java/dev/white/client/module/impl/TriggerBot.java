package dev.white.client.module.impl;

import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.ForcedKeys;
import dev.white.client.util.Friends;
import dev.white.client.util.SmoothLook;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * Attacks automatically whenever the crosshair is on a valid target. The hit is interactionManager.attackEntity + a
 * hand swing (so Auto Mace Swap keeps working), and it is purely time based:
 *  - Sword delay / Axe delay (ms, a random value between min and max is rolled after every hit): the hit is made once
 *    this long has passed since the last one. All Items uses the sword delay for any held item.
 *  - Work In Screen / While Use / On Left Click: when the bot is allowed to act.
 *  - While Ascending: off = no hits while rising from a jump.   Only Crit Sword / Axe: only hits while falling.
 *  - Check Shield: skips players blocking with a shield that faces you (not when Auto Shield Break has an axe ready).
 *  - Stray Bypass: also hits zombies.   All Entities: hits anything under the crosshair.
 *  - Same Player: only hits the entity you hit last (for 5 s), good for FFA.
 *  - Use Shield: while waiting for the next hit, holds right click with an offhand shield for Shield Time ms.
 *  - Look at target: after a hit your view smoothly turns to the target (Look speed = max degrees per tick).
 */
public class TriggerBot extends Module {
    private final Setting.Bool inScreen = add(new Setting.Bool("Work in screen", false));
    private final Setting.Bool whileUse = add(new Setting.Bool("While use", false));
    private final Setting.Bool onLeftClick = add(new Setting.Bool("On left click", false));
    private final Setting.Bool allItems = add(new Setting.Bool("All items (sword delay)", false));
    private final Setting.Num swordMin = add(new Setting.Num("Sword delay min (ms)", 540, 0, 1000, 1));
    private final Setting.Num swordMax = add(new Setting.Num("Sword delay max (ms)", 550, 0, 1000, 1));
    private final Setting.Num axeMin = add(new Setting.Num("Axe delay min (ms)", 780, 0, 1000, 1));
    private final Setting.Num axeMax = add(new Setting.Num("Axe delay max (ms)", 800, 0, 1000, 1));
    private final Setting.Bool checkShield = add(new Setting.Bool("Check shield", false));
    private final Setting.Bool whileAscend = add(new Setting.Bool("While ascending", false));
    private final Setting.Bool sticky = add(new Setting.Bool("Same player", false));
    private final Setting.Bool onlyCritSword = add(new Setting.Bool("Only crit sword", false));
    private final Setting.Bool onlyCritAxe = add(new Setting.Bool("Only crit axe", false));
    private final Setting.Bool swing = add(new Setting.Bool("Swing hand", true));
    private final Setting.Bool strayBypass = add(new Setting.Bool("Stray bypass", false));
    private final Setting.Bool allEntities = add(new Setting.Bool("All entities", false));
    private final Setting.Bool useShield = add(new Setting.Bool("Use shield", false));
    private final Setting.Num shieldTime = add(new Setting.Num("  Shield time (ms)", 350, 100, 1000, 1));
    private final Setting.Bool lookAtTarget = add(new Setting.Bool("Look at target", true));
    private final Setting.Num lookSpeed = add(new Setting.Num("  Look speed (deg/tick)", 20, 2, 60, 1));

    private static final long STICKY_MS = 5000;
    private static final int LOOK_TICKS = 10;

    private final Random rng = new Random();
    private long lastHitMs;
    private int swordDelay, axeDelay;
    // same player
    private Entity lastTarget;
    private long lastTargetMs;
    // shield hold
    private boolean shieldHeld;
    private long shieldUntil;
    // smooth look at the entity we hit
    private Entity lookTarget;
    private int lookTicks;

    public TriggerBot() { super("Trigger Bot", Category.COMBAT); }

    @Override
    protected void onEnable() {
        swordDelay = roll(swordMin.value, swordMax.value);
        axeDelay = roll(axeMin.value, axeMax.value);
        lastHitMs = System.currentTimeMillis();
        lastTarget = null; lookTarget = null; lookTicks = 0;
    }

    @Override
    protected void onDisable() {
        releaseShield();
        lastTarget = null; lookTarget = null; lookTicks = 0;
    }

    private int roll(double a, double b) {
        int lo = (int) Math.min(a, b), hi = (int) Math.max(a, b);
        return lo == hi ? lo : lo + rng.nextInt(hi - lo + 1);
    }

    private boolean mouseDown(int button) {
        return mc.getWindow() != null && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), button) == GLFW.GLFW_PRESS;
    }

    /** Start of the tick (before the movement packet): one smooth turn step toward the entity we last hit. */
    @Override
    public void onPreTick() {
        if (mc.player == null || mc.world == null || lookTarget == null) return;
        if (!lookAtTarget.value || lookTicks <= 0 || !lookTarget.isAlive() || mc.currentScreen != null || Freecam.active()) {
            lookTarget = null;
            return;
        }
        lookTicks--;
        SmoothLook.step(lookTarget, lookSpeed.value);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) { releaseShield(); return; }
        long now = System.currentTimeMillis();
        if (shieldHeld && now >= shieldUntil) releaseShield();

        if (!inScreen.value && mc.currentScreen != null) return;
        if (Freecam.active() || mc.player.isSpectator()) return;
        if (mc.getWindow() == null || !mc.isWindowFocused()) return;

        if (onLeftClick.value && !mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT)) return;

        ItemStack off = mc.player.getOffHandStack();
        if (!whileUse.value && (off.contains(DataComponentTypes.FOOD) || off.isOf(Items.SHIELD))
                && mouseDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT)) return;

        if (!whileAscend.value && !mc.player.isOnGround()
                && (mc.player.getVelocity().y > 0 || mc.player.fallDistance <= 0.0F)) return;

        ItemStack held = mc.player.getMainHandStack();
        boolean axe = !allItems.value && held.isIn(ItemTags.AXES);
        boolean sword = allItems.value || held.isIn(ItemTags.SWORDS);
        if (!axe && !sword) return;

        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || hit.getType() != HitResult.Type.ENTITY) return;
        Entity entity = hit.getEntity();
        if (!valid(entity)) return;

        if (sticky.value && lastTarget != null && lastTarget.isAlive() && now - lastTargetMs < STICKY_MS
                && entity != lastTarget) return;

        if (entity instanceof PlayerEntity p && checkShield.value && p.isBlocking() && !shieldFacingAway(p)) {
            // Auto Shield Break with an axe ready handles shields, so don't hold back then
            if (!(AutoShieldBreak.active() && hasHotbarAxe())) return;
        }

        if ((axe ? onlyCritAxe.value : onlyCritSword.value) && mc.player.fallDistance <= 0.0F) return;

        int delay = axe ? axeDelay : swordDelay;
        if (now - lastHitMs >= delay) {
            attack(entity, now);
            swordDelay = roll(swordMin.value, swordMax.value);
            axeDelay = roll(axeMin.value, axeMax.value);
        } else if (useShield.value && off.isOf(Items.SHIELD) && !shieldHeld) {
            ForcedKeys.force(mc.options.useKey);                // block while waiting for the next hit
            shieldHeld = true;
            shieldUntil = now + shieldTime.intValue();
        }
    }

    private void attack(Entity target, long now) {
        if (shieldHeld && mc.player.isBlocking()) releaseShield();      // can't hit with the shield up
        if (lookAtTarget.value) { lookTarget = target; lookTicks = LOOK_TICKS; }
        AutoMaceSwap.beforeAttack();                            // select the mace first; attackEntity syncs the slot to the server
        mc.interactionManager.attackEntity(mc.player, target);
        if (swing.value) mc.player.swingHand(Hand.MAIN_HAND);
        AutoMaceSwap.afterAttack();                             // back to the sword in the same tick
        lastHitMs = now;
        lastTarget = target;
        lastTargetMs = now;
    }

    private void releaseShield() {
        if (!shieldHeld) return;
        shieldHeld = false;
        ForcedKeys.release(mc.options.useKey);
        KeyBinding.updatePressedStates();
    }

    /** The blocking player is looking away from you, so the shield does not cover the hit. */
    private boolean shieldFacingAway(PlayerEntity p) {
        Vec3d toPlayer = p.getPos().subtract(mc.player.getPos()).normalize();
        return p.getRotationVec(1.0f).dotProduct(toPlayer) > 0;
    }

    private boolean hasHotbarAxe() {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) { ItemStack s = inv.getStack(i); if (!s.isEmpty() && s.isIn(ItemTags.AXES)) return true; }
        return false;
    }

    private boolean valid(Entity e) {
        if (e == null || e == mc.player || !e.isAlive() || Friends.shield(e)) return false;
        if (e instanceof PlayerEntity p) return !p.isSpectator();
        if (strayBypass.value && e instanceof ZombieEntity) return true;
        return allEntities.value;
    }
}
