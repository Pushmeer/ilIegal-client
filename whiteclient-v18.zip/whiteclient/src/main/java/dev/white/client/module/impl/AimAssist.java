package dev.white.client.module.impl;

import dev.white.client.module.Category;
import dev.white.client.module.Module;
import dev.white.client.setting.Setting;
import dev.white.client.util.Friends;
import dev.white.client.util.Look;
import dev.white.client.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Gently pulls your view toward the target nearest your crosshair (inside a field of view). It is not a snap like
 * Kill Aura: it steers your turn SPEED, not your angle.
 *
 * Target picking runs once per tick (20x/s). The steering runs every rendered frame, so it is smooth at any fps
 * and uses the same time step whatever the frame rate is:
 *   1. The aim point is read from the target's interpolated (per-frame) position, not its once-per-tick one.
 *   2. Wanted turn speed = error * Strength, plus the target's own sideways angular speed ("Target lead"), so a
 *      strafing player is followed instead of chased.
 *   3. It is capped by Max speed, faded out inside the dead zone, then eased into with a low-pass ("Smoothing"),
 *      so the pull starts and stops softly. A step never overshoots the target.
 *   4. "Yield to mouse": when you move the mouse against the pull, the assist backs off for a moment, so you
 *      stay in control of flicks and re-aims.
 * The turn is applied through the same path as real mouse movement, which keeps the camera interpolation smooth.
 */
public class AimAssist extends Module {
    private static final long CLICK_MEMORY_MS = 350;
    private static final double MOUSE_UNIT = 0.15;   // degrees of turn per mouse count (vanilla)

    private final Setting.Num range = add(new Setting.Num("Range", 6.0, 1.0, 10.0, 0.5));
    private final Setting.Num fov = add(new Setting.Num("FOV", 90, 10, 360, 10));
    private final Setting.Num maxSpeed = add(new Setting.Num("Max speed (deg/s)", 240, 30, 720, 10));
    private final Setting.Num strength = add(new Setting.Num("Strength %", 50, 5, 100, 5));
    private final Setting.Num smooth = add(new Setting.Num("Smoothing %", 40, 5, 100, 5));
    private final Setting.Num lead = add(new Setting.Num("Target lead %", 60, 0, 150, 10));
    private final Setting.Num deadZone = add(new Setting.Num("Dead zone (deg)", 0.4, 0.0, 3.0, 0.1));
    private final Setting.Num vertSpeed = add(new Setting.Num("Vertical speed %", 70, 10, 100, 5));
    private final Setting.Num aimHeight = add(new Setting.Num("Aim height %", 70, 10, 100, 5));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Other mobs", false));
    private final Setting.Bool vertical = add(new Setting.Bool("Vertical", true));
    private final Setting.Bool yieldMouse = add(new Setting.Bool("Yield to mouse", true));
    /** Off (default) = Aim Assist is a plain toggle: on = always active. On = it only pulls while left click is held. */
    private final Setting.Bool needAttack = add(new Setting.Bool("Hold click to aim", false));
    private final Setting.Bool needSight = add(new Setting.Bool("Need line of sight", true));
    private final Setting.Bool pauseUsing = add(new Setting.Bool("Pause while using item", true));
    private final Setting.Bool showStatus = add(new Setting.Bool("Show status", true));

    private long lastAttack;
    private String status = "";
    private int statusColor = Look.MUTED;

    // chosen once per tick, steered every frame
    private Entity target;

    // controller state (reset whenever the target changes or the assist pauses)
    private long lastFrameNs;
    private double velYaw, velPitch;                 // current turn speed, deg/s
    private double leadYawRate, leadPitchRate;       // smoothed angular speed of the target's bearing, deg/s
    private double lastWantYaw, lastWantPitch;
    private boolean haveLast;
    private double appliedYaw, appliedPitch;         // our view right after the last change we made
    private boolean haveApplied;
    private double yieldYaw, yieldPitch;             // seconds of backing off left, per axis

    public AimAssist() { super("Aim Assist", Category.COMBAT); }

    @Override protected void onEnable() { resetController(); }
    @Override protected void onDisable() { status = ""; target = null; resetController(); }

    private void resetController() {
        velYaw = velPitch = 0;
        leadYawRate = leadPitchRate = 0;
        haveLast = false;
        haveApplied = false;
        yieldYaw = yieldPitch = 0;
    }

    private boolean mouseDown() {
        return mc.getWindow() != null
                && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    private void say(String s, int color) { status = s; statusColor = color; }

    /** Runs every frame: reads the mouse button, steers the view, draws the status tag. */
    @Override
    public void onHud(DrawContext g) {
        if (mc.player == null || mc.currentScreen != null) { lastFrameNs = 0; return; }
        if (mouseDown()) lastAttack = System.currentTimeMillis();
        steer();
        if (showStatus.value && !status.isEmpty()) {
            Look.tagClamped(g, mc.textRenderer, status, Projector.width() / 2, Projector.height() / 2 + 22, statusColor);
        }
    }

    /** Runs 20x/s: decides WHO to aim at (and whether to aim at all). */
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) { target = null; return; }
        if (mc.currentScreen != null) { drop(""); return; }
        if (mouseDown()) lastAttack = System.currentTimeMillis();
        if (Freecam.active() || Freelook.active() || mc.player.isSpectator()) { drop("Aim: paused (freecam/freelook)"); return; }
        if (pauseUsing.value && mc.player.isUsingItem()) { drop("Aim: paused (using item)"); return; }
        if (needAttack.value && System.currentTimeMillis() - lastAttack > CLICK_MEMORY_MS) { drop("Aim: hold click"); return; }

        Vec3d eye = mc.player.getEyePos();
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        double half = fov.value / 2.0;

        Entity best = null;
        double bestAngle = Double.MAX_VALUE, currentAngle = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!valid(e)) continue;
            if (mc.player.distanceTo(e) > range.value) continue;
            if (needSight.value && !mc.player.canSee(e)) continue;
            Vec3d p = e.getEntityPos().add(0, e.getHeight() * aimHeight.value / 100.0, 0);
            double[] a = angles(eye, p);
            double ang = Math.hypot(MathHelper.wrapDegrees(a[0] - yaw), a[1] - pitch);
            if (e == target) currentAngle = ang;
            if (ang > half || ang >= bestAngle) continue;
            bestAngle = ang;
            best = e;
        }
        // stickiness: keep the current target unless another one is clearly closer to the crosshair
        if (target != null && best != target && currentAngle <= half && currentAngle - bestAngle < 8.0) best = target;

        if (best == null) { drop("Aim: no target"); return; }
        if (best != target) resetController();
        target = best;
        say("Aim: " + best.getName().getString(), Look.GOOD);
    }

    private void drop(String why) {
        target = null;
        resetController();
        say(why, why.contains("paused") ? Look.WARN : Look.MUTED);
    }

    /** Runs every frame: one smooth, frame-rate independent step toward the target. */
    private void steer() {
        long now = System.nanoTime();
        double dt = lastFrameNs == 0 ? 1.0 / 60.0 : (now - lastFrameNs) / 1.0e9;
        lastFrameNs = now;
        dt = MathHelper.clamp(dt, 0.001, 0.05);

        Entity t = target;
        if (t == null || !t.isAlive() || mc.player == null || mc.world == null) { resetController(); return; }
        if (mc.player.distanceTo(t) > range.value + 1.0) { resetController(); return; }

        // positions at this exact frame (interpolated), so the aim point moves smoothly between ticks
        float pt = Projector.tickProgress;
        Vec3d me = mc.player.getLerpedPos(pt);
        double eyeOffset = mc.player.getEyePos().y - mc.player.getY();
        Vec3d from = new Vec3d(me.x, me.y + eyeOffset, me.z);
        Vec3d tp = t.getLerpedPos(pt);
        Vec3d aim = new Vec3d(tp.x, tp.y + t.getHeight() * aimHeight.value / 100.0, tp.z);
        double[] want = angles(from, aim);

        double yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        double errYaw = MathHelper.wrapDegrees(want[0] - yaw);
        double errPitch = want[1] - pitch;

        // angular speed of the target's bearing: the feed-forward term that keeps a strafing target in the middle
        if (haveLast) {
            double ry = MathHelper.wrapDegrees(want[0] - lastWantYaw) / dt;
            double rp = (want[1] - lastWantPitch) / dt;
            double a = 1.0 - Math.exp(-dt / 0.06);
            leadYawRate += (MathHelper.clamp(ry, -360, 360) - leadYawRate) * a;
            leadPitchRate += (MathHelper.clamp(rp, -360, 360) - leadPitchRate) * a;
        }
        lastWantYaw = want[0];
        lastWantPitch = want[1];
        haveLast = true;

        // did the player turn on their own since our last step, and against our pull? then back off briefly
        yieldYaw = Math.max(0, yieldYaw - dt);
        yieldPitch = Math.max(0, yieldPitch - dt);
        if (yieldMouse.value && haveApplied) {
            double extYaw = MathHelper.wrapDegrees(yaw - appliedYaw);
            double extPitch = pitch - appliedPitch;
            if (Math.abs(extYaw) > 0.2 && Math.signum(extYaw) != Math.signum(errYaw)) yieldYaw = 0.25;
            if (Math.abs(extPitch) > 0.2 && Math.signum(extPitch) != Math.signum(errPitch)) yieldPitch = 0.25;
        }

        double combined = Math.hypot(errYaw, errPitch);
        double fade = smoothStep(deadZone.value, deadZone.value + 2.5, combined);   // quiet when already on target
        double gain = 3.0 + 12.0 * strength.value / 100.0;                           // 1/s
        double leadK = lead.value / 100.0;
        double maxYaw = maxSpeed.value, maxPitch = maxSpeed.value * vertSpeed.value / 100.0;

        double wantVelYaw = MathHelper.clamp((errYaw * gain + leadYawRate * leadK) * fade, -maxYaw, maxYaw);
        double wantVelPitch = MathHelper.clamp((errPitch * gain + leadPitchRate * leadK) * fade, -maxPitch, maxPitch);
        if (yieldYaw > 0) wantVelYaw *= 0.2;
        if (yieldPitch > 0) wantVelPitch *= 0.2;
        if (!vertical.value) wantVelPitch = 0;

        // low-pass the speed: soft start and stop. Smoothing 5%..100% -> time constant 0.02 s .. 0.20 s
        double tau = 0.01 + 0.19 * smooth.value / 100.0;
        double blend = 1.0 - Math.exp(-dt / tau);
        velYaw += (wantVelYaw - velYaw) * blend;
        velPitch += (wantVelPitch - velPitch) * blend;

        double stepYaw = velYaw * dt, stepPitch = velPitch * dt;
        // never travel past the target within one step
        if (Math.signum(stepYaw) == Math.signum(errYaw) && Math.abs(stepYaw) > Math.abs(errYaw)) { stepYaw = errYaw; velYaw = stepYaw / dt; }
        if (Math.signum(stepPitch) == Math.signum(errPitch) && Math.abs(stepPitch) > Math.abs(errPitch)) { stepPitch = errPitch; velPitch = stepPitch / dt; }
        if (Math.abs(stepYaw) < 1.0e-4 && Math.abs(stepPitch) < 1.0e-4) { appliedYaw = yaw; appliedPitch = pitch; haveApplied = true; return; }

        // same path as the real mouse (shifts the previous rotation too, so the camera stays smooth between ticks)
        mc.player.changeLookDirection(stepYaw / MOUSE_UNIT, stepPitch / MOUSE_UNIT);
        appliedYaw = mc.player.getYaw();
        appliedPitch = mc.player.getPitch();
        haveApplied = true;
    }

    private boolean valid(Entity e) {
        if (e == mc.player || !e.isAlive()) return false;
        if (e instanceof PlayerEntity p) return players.value && !p.isSpectator() && !Friends.shield(p);
        return e instanceof LivingEntity && mobs.value;
    }

    private static double smoothStep(double edge0, double edge1, double x) {
        double n = MathHelper.clamp((x - edge0) / Math.max(1.0e-6, edge1 - edge0), 0.0, 1.0);
        return n * n * (3.0 - 2.0 * n);
    }

    /** {yaw, pitch} in degrees that look from "from" at "to". */
    private static double[] angles(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new double[]{yaw, pitch};
    }
}
